// --- Definições Gerais ---
let larguraTela = 600;
let alturaTela = 400;
let nuvens = [];
let numNuvens = 5;
let gotas = [];
let evaporações = [];
let contadorEvaporadas = 0;

// --- Cores ---
let corCeu;
let corTerra;
let corAgua;
let corPlanta;
let corChuva;
let corEvaporacao;
let corTexto;

// --- Textos Informativos ---
let textoCondensacao = "Condensação: O vapor de água se transforma em gotas nas nuvens.";
let textoEvaporacao = "Evaporação: A água líquida vira vapor e sobe.";
let textoPrecipitacao = "Precipitação: Gotas caem como chuva.";
let textoInfiltracao = "Infiltração: A água penetra no solo.";
let textoEscorrimento = "Escorrimento: A água corre na superfície.";
let mensagemPreservacao = "Preserve a Água: Um recurso essencial!";
let textoAtivo = ""; // Texto atual da interação

// --- Estados de Interação ---
let nuvemInteragida = -1;
let plantaInteragida = false;
let crescimentoPlanta = 60; // Altura inicial da planta

function setup() {
  createCanvas(larguraTela, alturaTela);
  corCeu = color(135, 206, 235);
  corTerra = color(139, 69, 19);
  corAgua = color(0, 0, 255);
  corPlanta = color(0, 128, 0);
  corChuva = color(0, 0, 139);
  corEvaporacao = color(255, 255, 255, 150);
  corTexto = color(0);

  for (let i = 0; i < numNuvens; i++) {
    nuvens.push({
      x: random(larguraTela),
      y: random(50, 150),
      largura: random(50, 100),
      altura: random(30, 60),
      velocidade: random(0.5, 1.5),
      opacidade: 100
    });
  }

  // Cria botão de reinício
  let botao = createButton("Reiniciar");
  botao.position(10, alturaTela + 10);
  botao.mousePressed(() => {
    gotas = [];
    evaporações = [];
    contadorEvaporadas = 0;
    crescimentoPlanta = 60;
    textoAtivo = "";
  });
}

function draw() {
  background(corCeu);
  desenharCenario();
  animarNuvens();
  desenharNuvens();
  simularPrecipitacao();
  desenharPrecipitacao();
  simularEvaporacao();
  desenharEvaporacao();
  exibirTextoInteracao();
  exibirMensagemPreservacao();
  exibirContador();
}

// --- Desenho do cenário e elementos ---
function desenharCenario() {
  fill(corTerra);
  rect(0, alturaTela * 0.7, larguraTela, alturaTela * 0.3);
  fill(corAgua);
  ellipse(larguraTela * 0.3, alturaTela * 0.85, 150, 50);
  fill(corPlanta);
  rect(larguraTela * 0.7, alturaTela * 0.65 + (60 - crescimentoPlanta), 30, crescimentoPlanta);
}

function desenharNuvens() {
  noStroke();
  for (let nuvem of nuvens) {
    fill(255, nuvem.opacidade);
    ellipse(nuvem.x, nuvem.y, nuvem.largura, nuvem.altura);
  }
}

function desenharPrecipitacao() {
  fill(corChuva);
  noStroke();
  for (let gota of gotas) {
    ellipse(gota.x, gota.y, 3, 10);
  }
}

function desenharEvaporacao() {
  noFill();
  for (let p of evaporações) {
    stroke(255, 255, 255, p.alpha);
    ellipse(p.x, p.y, 5, 5);
  }
}

function exibirTextoInteracao() {
  fill(corTexto);
  textSize(14);
  textAlign(LEFT, TOP);
  text(textoAtivo, 20, 20, larguraTela * 0.4);
}

function exibirMensagemPreservacao() {
  fill(corTexto);
  textSize(18);
  textAlign(CENTER, BOTTOM);
  text(mensagemPreservacao, larguraTela / 2, alturaTela - 20);
}

function exibirContador() {
  fill(0);
  textSize(14);
  textAlign(RIGHT, TOP);
  text("Evaporações: " + contadorEvaporadas, larguraTela - 10, 10);
}

// --- Animações ---
function animarNuvens() {
  for (let nuvem of nuvens) {
    nuvem.x += nuvem.velocidade;
    if (nuvem.x > larguraTela + nuvem.largura / 2) {
      nuvem.x = -nuvem.largura / 2;
    }
  }
}

// --- Simulações físicas ---
function simularPrecipitacao() {
  for (let nuvem of nuvens) {
    if (random(1) < 0.02) {
      nuvem.opacidade = min(nuvem.opacidade + 10, 255); // Aumenta opacidade (condensação)
      let numGotas = floor(random(3, 8));
      for (let i = 0; i < numGotas; i++) {
        gotas.push({
          x: random(nuvem.x - nuvem.largura / 2, nuvem.x + nuvem.largura / 2),
          y: nuvem.y + nuvem.altura / 2,
          velocidadeY: random(2, 5)
        });
      }
    }
  }

  for (let i = gotas.length - 1; i >= 0; i--) {
    gotas[i].y += gotas[i].velocidadeY;

    // Chuva sobre planta
    if (
      gotas[i].x > larguraTela * 0.7 &&
      gotas[i].x < larguraTela * 0.7 + 30 &&
      gotas[i].y > alturaTela * 0.65 &&
      gotas[i].y < alturaTela
    ) {
      crescimentoPlanta = min(crescimentoPlanta + 2, 90);
      gotas.splice(i, 1);
      continue;
    }

    // Chuva sobre lago
    if (dist(gotas[i].x, gotas[i].y, larguraTela * 0.3, alturaTela * 0.85) < 80) {
      simularEvaporacaoPonto(gotas[i].x, gotas[i].y);
      gotas.splice(i, 1);
      continue;
    }

    // Fora da tela
    if (gotas[i].y > alturaTela) {
      gotas.splice(i, 1);
    }
  }
}

function simularEvaporacao() {
  if (frameCount % 30 === 0) {
    for (let i = 0; i < random(2, 4); i++) {
      evaporações.push({
        x: random(larguraTela * 0.2, larguraTela * 0.4),
        y: alturaTela * 0.85 + random(-10, 10),
        velocidadeY: random(-1.5, -0.5),
        alpha: 255
      });
      contadorEvaporadas++;
    }
  }

  for (let i = evaporações.length - 1; i >= 0; i--) {
    let p = evaporações[i];
    p.y += p.velocidadeY;
    p.alpha -= 3;
    if (p.alpha <= 0 || p.y < 100) {
      evaporações.splice(i, 1);
    }
  }
}

function simularEvaporacaoPonto(x, y) {
  for (let i = 0; i < 3; i++) {
    evaporações.push({
      x: x + random(-5, 5),
      y: y,
      velocidadeY: random(-1.5, -0.5),
      alpha: 255
    });
    contadorEvaporadas++;
  }
}

// --- Interação ---
function mouseClicked() {
  for (let i = 0; i < nuvens.length; i++) {
    let d = dist(mouseX, mouseY, nuvens[i].x, nuvens[i].y);
    if (d < max(nuvens[i].largura / 2, nuvens[i].altura / 2)) {
      textoAtivo = textoCondensacao;
      nuvemInteragida = i;
      plantaInteragida = false;
      return;
    }
  }

  if (
    mouseX > larguraTela * 0.7 &&
    mouseX < larguraTela * 0.7 + 30 &&
    mouseY > alturaTela * 0.65 &&
    mouseY < alturaTela
  ) {
    textoAtivo = "A planta usa a água da chuva para crescer!";
    plantaInteragida = true;
    nuvemInteragida = -1;
  } else {
    textoAtivo = "";
    plantaInteragida = false;
  }
}

function mouseMoved() {
  cursor(ARROW);
  for (let nuvem of nuvens) {
    if (dist(mouseX, mouseY, nuvem.x, nuvem.y) < max(nuvem.largura / 2, nuvem.altura / 2)) {
      cursor(HAND);
      return;
    }
  }

  if (
    mouseX > larguraTela * 0.7 &&
    mouseX < larguraTela * 0.7 + 30 &&
    mouseY > alturaTela * 0.65 &&
    mouseY < alturaTela
  ) {
    cursor(HAND);
  }
}
